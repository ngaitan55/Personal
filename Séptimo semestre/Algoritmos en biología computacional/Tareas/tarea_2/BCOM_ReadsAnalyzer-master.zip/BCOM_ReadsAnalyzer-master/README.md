# Kmer Distribution and Overlap Layout Consensus Tool

Homework 1 from the "Algorithms in Computationl Biology" at "Los Andes" University (Universidad de los Andes).
